import { MemoryGame } from './modules/gamemanager';

interface Card {
    symbol: string;
    element: HTMLDivElement;
}

function generateCards(cardSymbols: string[], gameBoardId: string, flipCardCallback: (card: Card) => void): void {
    const gameBoard = getElement(gameBoardId);
    cardSymbols.forEach(symbol => {
        const cardElement = document.createElement('div');
        cardElement.className = 'card';
        cardElement.textContent = '?';
        cardElement.onclick = () => flipCardCallback({ symbol, element: cardElement });
        gameBoard.appendChild(cardElement);
    });
}

function checkMatch(flippedCards: Card[], totalPairs: number, completionMessageId: string, onMatch: () => void): void {
    const [card1, card2] = flippedCards;
    if (card1.symbol === card2.symbol) {
        card1.element.classList.add('matched');
        card2.element.classList.add('matched');
        onMatch();
        if (flippedCards.length / 2 === totalPairs) {
            toggleVisibility(completionMessageId, true);
        }
    } else {
        card1.element.textContent = '?';
        card2.element.textContent = '?';
        card1.element.classList.remove('flipped');
        card2.element.classList.remove('flipped');
    }
    flippedCards.length = 0; // Clear the flipped cards array
}

function shuffle(array: string[]): void {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

function toggleVisibility(elementId: string, visible: boolean): void {
    const element = getElement(elementId);
    element.style.display = visible ? 'block' : 'none';
}

function getElement(id: string): HTMLElement {
    const element = document.getElementById(id);
    if (!element) throw new Error(`Element with ID "${id}" not found.`);
    return element;
}

const game = new MemoryGame('game-board', 'startbutton', 'completion-message');
document.getElementById('startbutton')?.addEventListener('click', () => game.startGame());
document.getElementById('completion-message')?.querySelector('button')?.addEventListener('click', () => game.restartGame());

const hintButton = document.createElement('button');
hintButton.textContent = 'Show Hint';
hintButton.className = 'btn btn-secondary my-3';
hintButton.style.display = 'block';
hintButton.style.margin = '0 auto';
hintButton.onclick = () => game.showHint();
document.body.appendChild(hintButton);
