import { toggleVisibility, getElement } from './ui-manager';
import { checkMatch, shuffle } from './statemanager';

export interface Card {
    symbol: string;
    element: HTMLDivElement;
}

export class MemoryGame {
    private flippedCards: Card[] = [];
    private cardSymbols: string[] = [];
    private matchedPairs: number = 0;
    private players: { name: string; score: number }[] = [
        { name: 'Player 1', score: 0 },
        { name: 'Player 2', score: 0 }
    ];
    private currentPlayerIndex: number = 0;
    private theme: string = 'fruits';

    constructor(
        private gameBoardId: string,
        private startButtonId: string,
        private completionMessageId: string
    ) {}

    public startGame(): void {
        this.theme = (document.getElementById('theme') as HTMLSelectElement).value;
        const pairCount = this.getSelectedPairCount();
        if (pairCount < 1 || pairCount > 8) {
            alert('Please enter a valid number of pairs (1-8).');
            return;
        }
        this.cardSymbols = this.generateCardSymbols(pairCount);
        toggleVisibility(this.startButtonId, false);
        toggleVisibility(this.gameBoardId, true);
        toggleVisibility('scoreboard', true);
        this.updateScoreboard();
        shuffle(this.cardSymbols);
        this.generateCards(this.cardSymbols, this.gameBoardId, card => this.flipCard(card));
    }

    private getSelectedPairCount(): number {
        const inputElement = document.getElementById('pair-count') as HTMLInputElement;
        return parseInt(inputElement.value, 10) || 0;
    }

    private generateCardSymbols(pairCount: number): string[] {
        const themes: { [key: string]: string[] } = {
            fruits: ['🍎', '🍌', '🍇', '🍒', '🍉', '🍓', '🍍', '🥝'],
            animals: ['🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼'],
            numbers: ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣']
        };
        const baseSymbols = themes[this.theme as keyof typeof themes] || themes['fruits'];
        return baseSymbols.slice(0, pairCount).flatMap((symbol: string) => [symbol, symbol]);
    }

    private generateCards(
        cardSymbols: string[],
        gameBoardId: string,
        flipCardCallback: (card: Card) => void
    ): void {
        const gameBoard = getElement(gameBoardId);
        cardSymbols.forEach(symbol => {
            const cardElement = document.createElement('div');
            cardElement.className = 'card';
            cardElement.textContent = '?';
            cardElement.onclick = () => flipCardCallback({ symbol, element: cardElement });
            gameBoard.appendChild(cardElement);
        });
    }

    private flipCard(card: Card): void {
        if (this.flippedCards.length < 2 && !card.element.classList.contains('flipped')) {
            card.element.textContent = card.symbol;
            card.element.classList.add('flipped');
            this.flippedCards.push(card);

            if (this.flippedCards.length === 2) {
                setTimeout(() => {
                    checkMatch(this.flippedCards, this.cardSymbols.length, this.completionMessageId, () => {
                        this.players[this.currentPlayerIndex].score++;
                        this.updateScoreboard();
                        if (this.isGameOver()) {
                            this.showEndGameSummary();
                        }
                    });
                    this.currentPlayerIndex = (this.currentPlayerIndex + 1) % this.players.length;
                    this.updateScoreboard();
                }, 500);
            }
        }
    }

    private isGameOver(): boolean {
        return this.players.reduce((total, player) => total + player.score, 0) === this.cardSymbols.length / 2;
    }

    private showEndGameSummary(): void {
        toggleVisibility(this.gameBoardId, false);
        toggleVisibility('scoreboard', false);
        toggleVisibility('end-game-summary', true);

        const finalScoresElement = document.getElementById('final-scores')!;
        const scores = this.players
            .map(player => `${player.name}: ${player.score}`)
            .join('<br>');
        finalScoresElement.innerHTML = `Final Scores:<br>${scores}`;
    }

    private updateScoreboard(): void {
        const playerTurnElement = document.getElementById('player-turn')!;
        const playerScoresElement = document.getElementById('player-scores')!;
        playerTurnElement.textContent = `${this.players[this.currentPlayerIndex].name}'s Turn`;
        playerScoresElement.innerHTML = this.players
            .map(player => `<li>${player.name}: ${player.score}</li>`)
            .join('');
    }

    public showHint(): void {
        this.flippedCards.forEach(card => {
            card.element.textContent = card.symbol;
        });
        setTimeout(() => {
            this.flippedCards.forEach(card => {
                card.element.textContent = '?';
            });
        }, 1000);
    }

    public restartGame(): void {
        const gameBoard = getElement(this.gameBoardId);
        gameBoard.innerHTML = '';
        this.matchedPairs = 0;
        shuffle(this.cardSymbols);
        this.generateCards(this.cardSymbols, this.gameBoardId, card => this.flipCard(card));
        toggleVisibility(this.completionMessageId, false);
    }
}
