enum GameState {
    NotStarted,
    GameSettingsSelection,
    GameSettingsConfirmation,
    InProgress,
    GameEnding,
    GameRestarting,
    Completed,
   }

   const currentState: GameState = GameState.NotStarted;

   if(currentState === GameState.NotStarted) {
    console.log("Game has not started yet.");
   } else if(currentState === GameState.GameSettingsSelection) {
    console.log("Game settings are being selected.");
   } else if(currentState === GameState.GameSettingsConfirmation) {
    console.log("Game settings are being confirmed.");
   } else if(currentState === GameState.InProgress) {
    console.log("Game is in progress.");
   } else if(currentState === GameState.GameEnding) {
    console.log("Game is ending.");
   } else if(currentState === GameState.GameRestarting) {
    console.log("Game is restarting.");
   } else if(currentState === GameState.Completed) {
    console.log("Game has been completed.");
   }