export function toggleVisibility(elementId: string, visible: boolean): void {
    const element = getElement(elementId);
    element.style.display = visible ? 'block' : 'none';
}

export function getElement(id: string): HTMLElement {
    const element = document.getElementById(id);
    if (!element) throw new Error(`Element with ID "${id}" not found.`);
    return element;
}
