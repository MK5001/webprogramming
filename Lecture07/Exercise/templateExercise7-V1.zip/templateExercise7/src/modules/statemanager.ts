import { Card } from './gamemanager';
import { getElement, toggleVisibility } from './ui-manager';

export function checkMatch(
    flippedCards: Card[],
    totalPairs: number,
    completionMessageId: string,
    onMatch: () => void
): void {
    const [card1, card2] = flippedCards;
    if (card1.symbol === card2.symbol) {
        card1.element.classList.add('matched');
        card2.element.classList.add('matched');
        onMatch();
        if (flippedCards.length / 2 === totalPairs) {
            toggleVisibility(completionMessageId, true);
        }
    } else {
        card1.element.textContent = '?';
        card2.element.textContent = '?';
        card1.element.classList.remove('flipped');
        card2.element.classList.remove('flipped');
    }
    flippedCards.length = 0; // Clear the flipped cards array
}

export function shuffle(array: string[]): void {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}
